package controller;

import model.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class GameController {

    private static int type=0;
    public static void start(Scanner scanner, String username, Connection connection) throws SQLException {
        System.out.println("Choose the type of the game with the number:");
        System.out.println("1.Two players");
        System.out.println("2.Bet");
        System.out.println("3.Single player");
        System.out.println("4.Clan");
        type = scanner.nextInt();
        if (type == 1){
            InputProcessor.currentMenu.setName("logIn");
            InputProcessor.isSecondUser = true;
            InputProcessor.doublePlayer = true;
        }
        else if (type == 2){
            InputProcessor.currentMenu.setName("logIn");
            InputProcessor.isSecondUser = true;
            InputProcessor.gamblePlayer = true;
        }
        else if (type == 3){
//            InputProcessor.currentMenu.setName("game");
            InputProcessor.singlePlayer = true;

        }
        else if (type == 4){
            InputProcessor.clanPlayer = true;

        }
    }

    public static void execute(User currentUser, User secondUser) throws SQLException {
        if(type == 1){
            currentUser.updateFromDatabase(DatabaseUtil.getConnection());
            secondUser.updateFromDatabase(DatabaseUtil.getConnection());
            DoublePlayer doublePlayer = new DoublePlayer(currentUser, secondUser);
            doublePlayer.execute();
            currentUser.reset();
            secondUser.reset();
//            secondUser = null;
            System.out.println("logged out of player 2.\n Game over.");
        }
        else if(type == 2){
            currentUser.updateFromDatabase(DatabaseUtil.getConnection());
            secondUser.updateFromDatabase(DatabaseUtil.getConnection());
            GambleMode gambleMode = new GambleMode(currentUser, secondUser);
            gambleMode.execute();
            currentUser.reset();
            secondUser.reset();
//            secondUser = null;
            System.out.println("logged out of player 2.\n Game over.");
        }

    }
    public static void executeSingle(User currentUser) throws SQLException {
        ArrayList<Card> computerOwned = new ArrayList<>();
        for (Card card: Store.getAllCards(DatabaseUtil.getConnection())){
            if(card.execution == null){
                computerOwned.add(card);
            }
        }
        Computer computer = new Computer("computer", computerOwned);
        SinglePlayer singlePlayer = new SinglePlayer(currentUser, computer);
        singlePlayer.execute();
    }
    static ClanMenu clanMenu = new ClanMenu();
    public static void executeClan(Scanner scanner, User currentUser) throws SQLException {
        clanMenu.execute(scanner, currentUser);
    }

}
