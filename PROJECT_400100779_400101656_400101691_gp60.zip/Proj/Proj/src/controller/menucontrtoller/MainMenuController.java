package controller.menucontrtoller;

import java.util.Scanner;
import model.InputProcessor;

public class MainMenuController {
    Scanner scanner = new Scanner(System.in);

    public MainMenuController(Scanner scanner) {
        this.scanner = scanner;
    }

    public void entrance(){
        System.out.println("Choose the number of the menu with the number:");
        System.out.println("1.Sign in");
        System.out.println("2.Log in");
        System.out.println("3.Game");
        System.out.println("4.Store");
        System.out.println("5.Profile");
        System.out.println("6.Game History");
        System.out.println("7.Exit");
        int n = scanner.nextInt();
        if (n == 1){
            InputProcessor.currentMenu.setName("signIn");
        }
        else if (n == 2){
            InputProcessor.currentMenu.setName("logIn");
        }
        else if (n == 3){
            InputProcessor.currentMenu.setName("game");
        }
        else if (n == 4){
            InputProcessor.currentMenu.setName("store");
        }
        else if (n == 5){
            InputProcessor.currentMenu.setName("profile");
        }
        else if (n == 6){
            InputProcessor.currentMenu.setName("gameHistory");
        }
        else if (n == 7){
            System.exit(0);
        }
    }

}
