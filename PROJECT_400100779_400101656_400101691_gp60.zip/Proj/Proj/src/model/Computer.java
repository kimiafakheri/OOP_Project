package model;

import java.util.ArrayList;

public class Computer extends User{
    public Computer(String name, ArrayList<Card> player2Owned) {
        this.setUsername(name);
        this.setOwnedCards(player2Owned);
    }

    public Computer() {
    }
}
