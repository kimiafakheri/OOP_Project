package model;

public class Weakener extends Card {
    //on the unused cards

    Weakener(){
        this.setCost(200);
        this.setCharacter("PAN");
        this.setName("Weakener");
    }

    @Override
    public void Activate(int playerOrder,User player, Hand hand, Board board,Round round) {
    }

}

