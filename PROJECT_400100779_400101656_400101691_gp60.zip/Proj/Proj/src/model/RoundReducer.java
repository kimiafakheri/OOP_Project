package model;

public class RoundReducer extends Card {

    RoundReducer(){
        this.setCost(200);
        this.setCharacter("KAI");
        this.setName("RoundReducer");
    }
    @Override
    public void Activate(int playerOrder,User player, Hand hand, Board board,Round round){

    }
}

