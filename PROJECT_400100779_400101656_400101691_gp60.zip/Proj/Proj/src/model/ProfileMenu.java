package model;

import model.DatabaseUtil;
import model.Menu;
import model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;

public class ProfileMenu extends Menu {
    String name = "profile";
    public ProfileMenu(String name) {
        super(name);
    }

    public static User showInformation(Connection conn, String username) throws SQLException {
        User user = User.fetchByUsername(conn, username);
        if (user != null) {
            return user;
        } else {
            return null;
        }
    }

    public static int canChangeUsername(Connection conn, String oldUsername, String newUsername) throws SQLException {
        User user = User.fetchByUsername(conn, oldUsername);
        if (user != null) {
            if (!newUsername.equals(oldUsername)) {
                return 1;
            } else {
                return 0;
            }
        } else {
            return 2;
        }
    }
    public static void changeUsername(Connection conn, User currentUser, String newUsername) throws SQLException {
        String sql = "UPDATE USER SET username = ? WHERE username = ?";
        if (!newUsername.equals(currentUser.getUsername())) {
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, newUsername);
                stmt.setString(2, currentUser.getUsername());
                int rowsUpdated = stmt.executeUpdate();
                if (rowsUpdated > 0) {
                    currentUser.setUsername(newUsername);
                }
            }
        }
    }
    public static int canChangeNickname(Connection conn, String username, String newNickname) throws SQLException {
        User user = User.fetchByUsername(conn, username);
        if (user != null) {
            if (!newNickname.equals(user.getNickname())) {
                return 1;
            } else {
                return 0;
            }
        } else {
            return 2;
        }
    }
    public static void changeNickname(Connection conn, String username, String newNickname) throws SQLException {
        String sql = "UPDATE USER SET nickname = ? WHERE username = ?";
        User user = User.fetchByUsername(DatabaseUtil.getConnection(), username);
        if (user != null) {
            if (!newNickname.equals(user.getNickname())) {
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, newNickname);
                    stmt.setString(2, username);
                    stmt.executeUpdate();
                    user.setNickname(newNickname);
                }
            }
        }
    }

    public static int changePassword(Connection conn, String username, String oldPassword, String newPassword) throws SQLException {
        User user = User.fetchByUsername(DatabaseUtil.getConnection(), username);
        if (user != null) {
            if (!user.getPassword().equals(oldPassword)) {
                return 1;
            }

            if (newPassword.equals(oldPassword)) {
                return 2;
            }

            if (!isValidPassword1(newPassword)) {
                return 31;
            }
            if (!isValidPassword2(newPassword)){
                return 32;
            }
            // CAPTCHA verification
            if (!verifyCaptcha()) {
                return 4;
            }
            String sql = "UPDATE USER SET password = ? WHERE username = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, newPassword);
                stmt.setString(2, username);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    user.setPassword(newPassword);
                    return 5;
                } else {
                    return 6;
                }
            }
        } else {
            return 7;
        }
    }
    public static int changePassword(Connection conn, String username, String newPassword) throws SQLException {
        User user = User.fetchByUsername(DatabaseUtil.getConnection(), username);
        if (user != null) {
            String sql = "UPDATE USER SET password = ? WHERE username = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, newPassword);
                stmt.setString(2, username);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    user.setPassword(newPassword);
                    return 1;
                } else {
                    return 0;
                }
            }
        } else {
            return 2;
        }
    }

    // Validate the password properties
    private static boolean isValidPassword1(String password) {
        return password.length() >= 8;
    }
    private static boolean isValidPassword2(String password){
        return password.matches(".*[A-Z].*") && password.matches(".*[a-z].*") && password.matches(".*\\d.*") && password.matches(".*[^a-zA-Z\\d].*");
    }
    // Simple CAPTCHA mechanism
    private static boolean verifyCaptcha() {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int a = random.nextInt(10);
        int b = random.nextInt(10);
        System.out.printf("CAPTCHA: What is %d + %d? ", a, b);
        int answer = scanner.nextInt();
        return answer == (a + b);
    }
    public static int changeEmail(Connection conn, String username, String newEmail) throws SQLException {
        String sql = "UPDATE USER SET email = ? WHERE username = ?";
        User user = User.fetchByUsername(DatabaseUtil.getConnection(), username);
        if (user != null) {
            if (!newEmail.equals(user.getEmail())) {
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, newEmail);
                    stmt.setString(2, username);
                    stmt.executeUpdate();
                    user.setEmail(newEmail);
                    return 1;
                }
            }
            else {
                return 0;
            }
        }
        else {
            return 2;
        }
    }

}

