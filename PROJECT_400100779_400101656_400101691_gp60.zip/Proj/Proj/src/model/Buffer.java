package model;

public class Buffer extends Card {

    Buffer(){
        this.setCost(200);
        this.setCharacter("KIM");
        super.setName("Buffer");
    }

    @Override
    public void Activate(int playerOrder,User player, Hand hand, Board board,Round round){

    }


}

