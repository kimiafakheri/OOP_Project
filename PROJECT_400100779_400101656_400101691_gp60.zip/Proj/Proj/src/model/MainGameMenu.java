package model;

import java.sql.Connection;
import java.sql.SQLException;

public class MainGameMenu extends Menu {
    String name = "main";

    public MainGameMenu(String name) {
        super(name);
    }


    public static void showMainMenu() {

    }

}
