package model;

public class LoginMenu extends Menu {
    String name = "Login";
    public LoginMenu(String name) {
        super(name);
    }
}
