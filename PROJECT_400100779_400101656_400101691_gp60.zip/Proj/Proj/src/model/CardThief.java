package model;

public class CardThief extends Card {

    CardThief(){
        this.setCost(200);
        this.setCharacter("PAN");
        this.setName("CardThief");
    }
    @Override
    public void Activate(int playerOrder,User player, Hand hand, Board board,Round round){

    }
}

