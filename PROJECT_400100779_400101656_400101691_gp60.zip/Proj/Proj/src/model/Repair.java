package model;

public class Repair extends Card {

    Repair(){
        this.setCost(200);
        this.setCharacter("PAR");
        this.setName("Repair");
    }

    @Override
    public void Activate(int playerOrder,User player, Hand hand, Board board,Round round){

    }
}
