package model;

public class Heal extends Card {
    Heal(){
        this.setCost(200);
        this.setCharacter("KAI");
        super.setDuration(1);
        super.setName("Heal");
    }

}
