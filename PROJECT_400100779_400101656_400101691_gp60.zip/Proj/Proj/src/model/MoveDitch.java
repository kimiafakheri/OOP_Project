package model;

public class MoveDitch extends Card {


    MoveDitch() {
        this.setCharacter("PAN");
        this.setCost(200);
        this.setName("MoveDitch");
    }

    @Override
    public void Activate(int playerOrder, User player, Hand hand, Board board, Round round) {

    }
}