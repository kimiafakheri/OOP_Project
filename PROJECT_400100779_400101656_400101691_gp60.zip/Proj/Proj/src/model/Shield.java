package model;

public class Shield extends Card {

    Shield() {
        this.setCost(200);
        this.setCharacter("KIM");
        this.setCardDefenseAttack(Integer.MAX_VALUE);
        this.setDuration(1);
        this.damagePerCell.clear();
        this.damagePerCell.add(0);
        this.setName("Shield");
        this.setPlayerDamage(0);
    }

}
